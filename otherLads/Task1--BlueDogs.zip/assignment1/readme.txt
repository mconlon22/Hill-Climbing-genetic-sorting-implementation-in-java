Team Name: Blue Dogs
Members: Oisín, Paddy, Shery
Team Leader: Oisín

On this interation of the project there's three seperate parts:

1) The student name generator, which generates all the student data needed except for the project preferences
2) The project mapper, which establishes a framework for mapping between students and projects with a normal
   distribution of preferences. This will be integrated with the student name generator to generate a complete
   csv of student data.
3) A seperate csv containing the projects and a generator for said file